library(testthat)
library(rPSI)

test_check("rPSI")
